var jtbc = window.jtbc || {};
jtbc.editor = {
  baseHref: null,
  replace: function(argStr)
  {
    return CKEDITOR.replace('content');
  },
  getHTML: function(argObj)
  {
    var myObj = argObj;
    return myObj.getData();
  },
  insertHTML: function(argObj, argName, argContent)
  {
    var myObj = argObj;
    var myContent = argContent;
    return myObj.insertHtml(myContent);
  }
};