<?php
ob_start();
session_start();
set_time_limit(1800);
ini_set('display_errors', '1');
//error_reporting(E_ALL ^ E_NOTICE);
define('APPNAME', 'jtbc_');
define('ASSETSPATH', 'common/assets');
define('BASEDIR', '');
define('CACHEDIR', 'cache');
define('CHARSET', 'utf-8');
define('CONSOLEDIR', 'console');
define('COOKIESPATH', '/');
define('DB', 'MySQL');
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'root');
define('DB_DATABASE', 'db_jtbc');
define('LANGUAGE', 'zh-cn');
define('SEPARATOR', ' - ');
define('THEME', 'default');
define('TEMPLATE', 'default');
define('VERSION', '3.0.0.0');
define('WEBKEY', 'J1T2B3C4');
define('XMLSFX', '.jtbc');
?>
