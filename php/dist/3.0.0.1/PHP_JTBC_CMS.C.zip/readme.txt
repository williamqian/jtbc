﻿版权申明：
JTBC由上海七慧网络科技有限公司开发支持。
纯净开源，任何个人和公司等均可免费使用。

目录说明：
wwwroot 目录为源码目录，请上传到服务器主目录。
db_jtbc.sql 为数据库脚本生成文件，请在MYSQL数据库中执行。

数据库配置：
wwwroot/common/incfiles/const.inc.php 文件中配置相应的数据库地址以及用户名密码。

define('DB_HOST', 'localhost'); //数据库地址//
define('DB_USERNAME', 'root'); //用户名//
define('DB_PASSWORD', 'root'); //密码//
define('DB_DATABASE', 'db_jtbc'); //数据库名称//

后台管理地址：
你的网站/console/