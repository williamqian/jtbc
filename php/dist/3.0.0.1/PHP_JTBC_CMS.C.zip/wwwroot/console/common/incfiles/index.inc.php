<?php
namespace jtbc;
class ui extends page {
  public static function getResult()
  {
    $tmpstr = tpl::take('index.index', 'tpl', 1);
    return $tmpstr;
  }
}
?>